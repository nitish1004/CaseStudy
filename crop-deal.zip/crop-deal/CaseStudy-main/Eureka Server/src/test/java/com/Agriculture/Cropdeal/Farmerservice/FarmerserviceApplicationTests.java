package com.Agriculture.Cropdeal.Farmerservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FarmerserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
